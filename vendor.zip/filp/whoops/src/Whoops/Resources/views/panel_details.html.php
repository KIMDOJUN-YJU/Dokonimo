<?php $tpl->render($frame_code) ?>
<?php $tpl->render($env_details) ?>